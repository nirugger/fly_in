class Manager:
    pass
