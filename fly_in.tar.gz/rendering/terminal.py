class TerminalVisualizer():
    pass
